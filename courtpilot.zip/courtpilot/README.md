# CourtPilot — Case Tracking & Notification Platform for Indian Lawyers

## Overview

CourtPilot is a SaaS platform that helps Indian litigation lawyers track their court cases and receive timely notifications about upcoming hearings, new orders, and case updates. It scrapes data from India's eCourts system and delivers notifications via Telegram (free), Email (free), and WhatsApp (premium).

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     COURTPILOT                          │
│                                                         │
│  ┌──────────┐   ┌──────────────┐   ┌────────────────┐  │
│  │ FastAPI   │   │   Celery     │   │  Notification  │  │
│  │ Backend   │◄─►│   Workers    │──►│  Pipeline      │  │
│  │           │   │              │   │                │  │
│  │ • Auth    │   │ • Poll cases │   │ • Telegram Bot │  │
│  │ • CRUD    │   │ • Diff check │   │ • Email (SMTP) │  │
│  │ • Plans   │   │ • Schedule   │   │ • WhatsApp API │  │
│  └─────┬─────┘   └──────┬───────┘   └────────────────┘  │
│        │                │                                │
│        ▼                ▼                                │
│  ┌──────────────────────────────┐                       │
│  │        PostgreSQL            │                       │
│  │  • Users & subscriptions     │                       │
│  │  • Tracked cases             │                       │
│  │  • Case snapshots & diffs    │                       │
│  │  • Notification log          │                       │
│  └──────────────────────────────┘                       │
│        │                                                │
│        ▼                                                │
│  ┌──────────────────────────────┐                       │
│  │        Redis                 │                       │
│  │  • Celery task broker        │                       │
│  │  • Case dedup cache          │                       │
│  │  • Rate limiting counters    │                       │
│  └──────────────────────────────┘                       │
└─────────────────────────────────────────────────────────┘

External:
  ┌──────────────────┐
  │ eCourts Services │  ← polled via bharat-courts SDK
  │ (NIC servers)    │    (district + HC + SC)
  └──────────────────┘
```

## Pricing Tiers

| Plan       | Cases | Channels           | Price/month |
|------------|-------|--------------------|-------------|
| Free       | 5     | Telegram + Email   | ₹0          |
| Starter    | 50    | Telegram + Email   | ₹299        |
| Pro        | 100   | Telegram + Email   | ₹499        |
| Firm       | 500   | Telegram + Email   | ₹1,499      |
| WhatsApp+  | —     | Add WhatsApp       | +₹199/mo    |

## Notification Schedule

- **Weekly digest**: Every Monday 8 AM — all upcoming hearings for the week
- **3-day reminder**: 3 days before hearing date
- **2-day reminder**: 2 days before hearing date
- **1-day reminder**: 1 day before hearing date (evening)
- **New order alert**: Whenever a new order/judgment is uploaded

## Tech Stack

- **Backend**: Python 3.12, FastAPI
- **Database**: PostgreSQL 16
- **Queue**: Celery + Redis
- **Scraping**: bharat-courts SDK (eCourts API)
- **Telegram**: python-telegram-bot
- **WhatsApp**: Meta Cloud API
- **Email**: aiosmtplib + Jinja2 templates
- **Deployment**: Docker + docker-compose

## Quick Start

```bash
# Clone and setup
cp .env.example .env
# Edit .env with your credentials

# Run with Docker
docker-compose up -d

# Or run locally
pip install -r requirements.txt
uvicorn app.main:app --reload
celery -A workers.celery_app worker -l info
celery -A workers.celery_app beat -l info
```
